from django.apps import AppConfig


class Lab3Config(AppConfig):
    name = 'lab3'
