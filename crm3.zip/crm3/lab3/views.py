from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return render(request,'index.html', )
    #return HttpResponse('this is homepage')


def about(request):
    return render(request,'about.html')
    #return render(request,'about.html',context)
    

def services(request):
    return render(request,'services.html')
    #return render(request,'services.html',context)
    #return HttpResponse('this is services page')



    #return render(request,'contact.html',context)
    #return HttpResponse('this is contact page')
def contact(request):
    return render(request,'contact.html')
    